/**
 * 
 */
/**
 * 
 */
module my_class_additions {
}