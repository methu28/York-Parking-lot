package my_class_additions_singleton;


public class ParkingSystem {

    private static ParkingSystem systemInstance = null;

    private ParkingSystem() {
    }

    public static ParkingSystem getInstance() {
        if (systemInstance == null) {
            systemInstance = new ParkingSystem();
        }
        return systemInstance;
    }

    public void runSystem() {
        System.out.println("Running Parking System...");
    }

  
}

