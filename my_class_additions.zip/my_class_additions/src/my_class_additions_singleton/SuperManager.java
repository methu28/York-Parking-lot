package my_class_additions_singleton;

public class SuperManager {

    private static SuperManager instance = null;

    private String name;

    private SuperManager(String name) {
        this.name = name;
    }

    public static SuperManager getInstance(String name) {
        if (instance == null) {
            instance = new SuperManager(name);
        }
        return instance;
    }

    public String getName() {
        return name;
    }

}