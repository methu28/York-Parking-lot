package my_class_additions_decorator;

public abstract class ParkingSlotDecorator implements ParkingSlot {
    protected ParkingSlot decoratedSlot;

    public ParkingSlotDecorator(ParkingSlot slot) {
        this.decoratedSlot = slot;
    }

    public String getDescription() {
        return decoratedSlot.getDescription();
    }

    public double getCost() {
        return decoratedSlot.getCost();
    }
}

