package my_class_additions_decorator;


public class BasicParkingSlot implements ParkingSlot {
    @Override
    public String getDescription() {
        return "Basic Parking Slot";
    }

    @Override
    public double getCost() {
        return 5.00;  // Base rate
    }
}

