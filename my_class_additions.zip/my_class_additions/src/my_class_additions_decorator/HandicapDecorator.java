package my_class_additions_decorator;

public class HandicapDecorator extends ParkingSlotDecorator {

    public HandicapDecorator(ParkingSlot slot) {
        super(slot);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Handicap Accessible";
    }

    @Override
    public double getCost() {
        return super.getCost() + 1.50;  // Extra cost for accessible design
    }
}

