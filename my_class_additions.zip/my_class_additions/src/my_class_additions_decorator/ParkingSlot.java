package my_class_additions_decorator;


public interface ParkingSlot {
    String getDescription();
    double getCost();
}

