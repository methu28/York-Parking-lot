package my_class_additions_decorator;

public class EVChargingDecorator extends ParkingSlotDecorator {

    public EVChargingDecorator(ParkingSlot slot) {
        super(slot);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + EV Charging";
    }

    @Override
    public double getCost() {
        return super.getCost() + 2.50;  // Extra cost for EV
    }
}
