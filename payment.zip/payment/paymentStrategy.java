
public interface paymentStrategy {
	boolean processPayment(double amount);
    boolean refund(double amount);

}
