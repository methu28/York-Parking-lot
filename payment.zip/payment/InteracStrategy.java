
public class InteracStrategy implements PaymentStrategy {
    @Override
    public boolean processPayment(double amount) {
        System.out.println("Processing Interac e-Transfer of $" + amount);
        // Actual Interac processing logic would go here
        return true;
    }

    @Override
    public boolean refund(double amount) {
        System.out.println("Refunding $" + amount + " via Interac e-Transfer");
        // Actual refund logic would go here
        return true;
    }
}
