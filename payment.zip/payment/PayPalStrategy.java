
public class PayPalStrategy implements PaymentStrategy {
    @Override
    public boolean processPayment(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
        return true;
    }

    @Override
    public boolean refund(double amount) {
        System.out.println("Refunding $" + amount + " via PayPal");

        return true;
    }
}
Intera