import parkingSystem.model.AbstractUser;

public class Payment {
    private String paymentID;
    private AbstractUser user;
    private double amount;
    private String paymentMethod;
    private boolean status;
    private PaymentStrategy paymentStrategy;
    public Payment(String paymentID, AbstractUser user, double amount, String paymentMethod) {
        this.paymentID = paymentID;
        this.user = user;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        initializePaymentStrategy();
    }
    private void initializePaymentStrategy() {
        switch (paymentMethod.toLowerCase()) {
            case "creditcard":
                this.paymentStrategy = new CreditCardStrategy();
                break;
            case "paypal":
                this.paymentStrategy = new PayPalStrategy();
                break;
            case "interac":
                this.paymentStrategy = new InteracStrategy();
                break;
            default:
                throw new IllegalArgumentException("Unsupported payment method: " + paymentMethod);
        }
    }

    public boolean processPayment() {
        double finalAmount = calculateFinalAmount();
        this.status = paymentStrategy.processPayment(finalAmount);
        return status;
    }

    public boolean refundPayment() {
        return paymentStrategy.refund(this.amount);
    }

    private double calculateFinalAmount() {
        return this.amount * getDiscountMultiplier();
    }

    private double getDiscountMultiplier() {
       
        if (user.getRole().equals("Student")) {
            return 0.9; 
        } else if (user.getRole().equals("Faculty")) {
            return 0.85; 
        }
        return 1.0;
    }

   
    public String getPaymentID() { 
    	return paymentID;
    	}
    public AbstractUser getUser() {
    	return user; 
    	}
    public double getAmount() {
    	return amount;
    	}
    public String getPaymentMethod() { 
    	return paymentMethod; 
    	}
    public boolean getStatus() { 
    	return status; 
    	}
}